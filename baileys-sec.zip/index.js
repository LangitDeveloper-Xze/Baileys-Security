async function kinglangitstart() {
const security = new MahiruSecurity();
    
    console.log('Sabar...\n');
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const sec = await security.runCheck();
    
    if (!sec) {
        const content = fs.readFileSync('./package.json', 'utf8');
        const packageJson = JSON.parse(content);
        const mah = packageJson.dependencies['@whiskeysockets/baileys'];
        
        security.showErrorMessage(mah);
        
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        
        console.log('contact: t.me/langitsensei');
        process.exit(1);
    }
    console.log('Oke\n');
    await new Promise(resolve => setTimeout(resolve, 800));
	const {
		state,
		saveCreds
	} = await useMultiFileAuthState("session")
	const kinglangit = makeWASocket({
		printQRInTerminal: !usePairingCode,
		syncFullHistory: true,
		markOnlineOnConnect: true,
		connectTimeoutMs: 60000,
		defaultQueryTimeoutMs: 0,
		keepAliveIntervalMs: 10000,
		generateHighQualityLinkPreview: true,
		patchMessageBeforeSending: (message) => {
			const requiresPatch = !!(
				message.buttonsMessage ||
				message.templateMessage ||
				message.listMessage
			);
			if (requiresPatch) {
				message = {
					viewOnceMessage: {
						message: {
							messageContextInfo: {
								deviceListMetadataVersion: 2,
								deviceListMetadata: {},
							},
							...message,
						},
					},
				};
			}

			return message;
		},
		version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
		browser: ["Ubuntu", "Chrome", "20.0.04"],
		logger: pino({
			level: 'fatal'
		}),
		auth: {
			creds: state.creds,
			keys: makeCacheableSignalKeyStore(state.keys, pino().child({
				level: 'silent',
				stream: 'store'
			})),
		}
	});


    if (usePairingCode && !kinglangit.authState.creds.registered) {
        const phoneNumber = await question('Masukkan Nomor Anda Awali 62 : 62xxx\n');
        const code = await kinglangit.requestPairingCode(phoneNumber.trim());
        console.log(`Berikut Kode Anda: ${code}`);
    }
    
    
    
    
// SESUAIIN AJA (GABISA?) LU DEV ABAL"