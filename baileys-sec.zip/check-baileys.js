const fs = require('fs');
const path = require('path');
const readline = require('readline');

class MahiruSecurity {
    constructor() {
        this.packagePath = path.join(__dirname, '..', '..', 'package.json');
    }
    
    async showLoading() {
        console.clear();
        console.log('Wait\n');
        
        const cr = [
            { text: 'Plis Bang/Kak', delay: 800 },
            { text: 'Yang Pakai Ini', delay: 700 },
            { text: 'Jangan', delay: 900 },
            { text: 'Hapus Credit', delay: 600 },
            { text: 'By LangitDev', delay: 850 }
        ];
        
        for (let i = 0; i < cr.length; i++) {
            process.stdout.write(`   ${cr[i].text}`);
            await this.sleep(cr[i].delay);
            console.log('~');
        }
        
        console.log('\n' + '='.repeat(50));
    }
    
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    async runCheck() {
        await this.showLoading();
        
        console.log('Mahiru Security');
        console.log('Developer: LangitDev');
        console.log('='.repeat(35) + '\n');
        
        try {
            const content = fs.readFileSync(this.packagePath, 'utf8');
            const packageJson = JSON.parse(content);
            const Baileys = packageJson.dependencies['@whiskeysockets/baileys'] || '';
            
            const isOriginal = Baileys.includes('FadelSM') && 
            Baileys.includes('Baileys');
            
            console.log('📊 STATUS CHECK:');
            console.log('├── Package: @whiskeysockets/baileys');
            console.log(`└── Repository: ${Baileys}`);
            console.log('');
            
            if (isOriginal) {
                console.log('Terverifikasi');
                console.log('🎉 Berhasil\n');
                return true;
            } else {
                console.log('Detect Baileys Modif');
                console.log('Lu Kontol!');
                console.log(`Found: ${Baileys}`);
                return false;
            }
            
        } catch (err) {
            console.log(' Err: Cannot read package.json');
            console.log('Err\n');
            return false;
        }
    }
    
    showErrorMessage(wops) {
        console.log('\n' + '⚠'.repeat(30));
        console.log('KONTOL');
        console.log('⚠'.repeat(30));
        console.log('\nSeseorang Mengganti Baileys Menjadi:', wops);
        console.log('\nwkwkw ketahuan ganti baileys skill cupu');
        console.log('Error? t.me/langitsensei');
        console.log('\n' + '='.repeat(45));
    }
}

module.exports = MahiruSecurity;